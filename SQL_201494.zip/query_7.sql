SELECT DISTINCT ROUND(price::numeric, 2) as PriceRounded
FROM "Sells";
