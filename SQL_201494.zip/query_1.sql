SELECT name
FROM "Beers"
WHERE manf = 'Anheuser-Busch';